export default {
  useNextVariants: true,
  fontSize: 11,
  fontFamily: ['Montserrat', 'sans-serif', 'Helvetica Neue', 'Arial'].join(',')
};
