export { default } from './PortletLabel';
