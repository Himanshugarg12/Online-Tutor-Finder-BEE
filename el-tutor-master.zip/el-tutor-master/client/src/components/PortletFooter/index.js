export { default } from './PortletFooter';
