export default theme => ({
  grid: {
    height: '100%'
  }
});
